"""
Module providing model inversion attacks.
"""
from art.attacks.inference.model_inversion.mi_face import MIFace
