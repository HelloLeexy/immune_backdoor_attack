"""
GAN Estimator API.
"""
from art.estimators.gan.tensorflow_gan import TensorFlow2GAN
